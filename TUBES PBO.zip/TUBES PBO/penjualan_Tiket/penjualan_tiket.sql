-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2025 at 09:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan_tiket`
--

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_kereta`
--

CREATE TABLE `jadwal_kereta` (
  `id_jadwal` int(11) NOT NULL,
  `nama_kereta` varchar(100) DEFAULT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_berangkat` time DEFAULT NULL,
  `kelas` enum('VIP','Ekonomi') DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `id_jurusan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_kereta`
--

INSERT INTO `jadwal_kereta` (`id_jadwal`, `nama_kereta`, `jurusan`, `tanggal`, `jam_berangkat`, `kelas`, `harga`, `id_jurusan`) VALUES
(1, 'KA-BAN', 'Bandung', '2025-05-28', '11:50:25', 'Ekonomi', 180000, 1),
(2, 'KA-78', 'Tegal', '2025-05-28', '08:00:00', 'VIP', 100000, 4),
(3, 'KA-78', 'Yogyakarta', '2025-05-28', '08:00:00', 'VIP', 150000, 2),
(4, 'KA-78', 'Yogyakarta', '2025-05-28', '08:00:00', 'Ekonomi', 120000, 2),
(5, 'KA-78', 'Yogyakarta', '2025-05-28', '08:00:00', 'VIP', 150000, 2),
(6, 'KA-78', 'Bandung', '2025-05-28', '08:00:00', 'VIP', 200000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE `jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `nama_jurusan` varchar(100) NOT NULL,
  `stasiun_awal` varchar(100) DEFAULT NULL,
  `stasiun_akhir` varchar(100) DEFAULT NULL,
  `jarak_km` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `nama_jurusan`, `stasiun_awal`, `stasiun_akhir`, `jarak_km`) VALUES
(1, 'Bandung', 'Stasiun Bandung', 'Stasiun Kiaracondong', 10),
(2, 'Yogyakarta', 'Stasiun Tugu', 'Stasiun Lempuyangan', 12),
(3, 'Jatibarang', 'Stasiun Jatibarang', 'Stasiun Jatibarang', 0),
(4, 'Tegal', 'Stasiun Tegal', 'Stasiun Slawi', 15),
(5, 'Bandung', NULL, NULL, NULL),
(6, 'Yogyakarta', NULL, NULL, NULL),
(7, 'Jatibarang', NULL, NULL, NULL),
(8, 'Tegal', NULL, NULL, NULL),
(9, 'Bandung - Yogyakarta', 'Bandung', 'Yogyakarta', 550),
(10, 'Bandung - Jatibarang', 'Bandung', 'Jatibarang', 150),
(11, 'Bandung - Tegal', 'Bandung', 'Tegal', 200);

-- --------------------------------------------------------

--
-- Table structure for table `kereta`
--

CREATE TABLE `kereta` (
  `id_kereta` int(11) NOT NULL,
  `nama_kereta` varchar(100) DEFAULT NULL,
  `jumlah_kursi` int(11) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penumpang`
--

CREATE TABLE `penumpang` (
  `id_penumpang` int(11) NOT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `nomor_kursi` varchar(10) DEFAULT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `kelas` enum('VIP','Ekonomi') DEFAULT NULL,
  `tanggal_pergi` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penumpang`
--

INSERT INTO `penumpang` (`id_penumpang`, `nama_lengkap`, `nomor_kursi`, `jurusan`, `kelas`, `tanggal_pergi`) VALUES
(1, 'ANDRIYANI DEWI', '2003', 'Bandung', 'Ekonomi', '2025-05-28'),
(2, 'REZA RAHADIAN', '8', 'Tegal', 'VIP', '2025-05-28'),
(3, 'MIHAMAD RIZAL', '32', 'Bandung', 'Ekonomi', '2025-05-28'),
(4, 'Nayu M', '3', 'Yogyakarta', 'Ekonomi', '2025-05-28'),
(5, 'rizki', '23', 'Yogyakarta', 'VIP', '2025-05-28');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_tiket`
--

CREATE TABLE `transaksi_tiket` (
  `id_transaksi` int(11) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `jenis_kelas` enum('VIP','Ekonomi') NOT NULL,
  `harga` int(11) NOT NULL,
  `nomor_kursi` varchar(10) NOT NULL,
  `nama_penumpang` varchar(100) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total_bayar` int(11) NOT NULL,
  `uang_bayar` int(11) NOT NULL,
  `uang_kembali` int(11) NOT NULL,
  `waktu_transaksi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_tiket`
--

INSERT INTO `transaksi_tiket` (`id_transaksi`, `jurusan`, `jenis_kelas`, `harga`, `nomor_kursi`, `nama_penumpang`, `jumlah_beli`, `total_bayar`, `uang_bayar`, `uang_kembali`, `waktu_transaksi`) VALUES
(1, 'Bandung', 'VIP', 200000, '1', 'delon', 1, 200000, 500000, 300000, '2025-05-27 04:29:59'),
(2, 'Yogyakarta', 'VIP', 150000, '1', 'andre', 1, 150000, 200000, 50000, '2025-05-27 06:46:05'),
(3, 'Tegal', 'Ekonomi', 80000, '1', 'nayu', 2, 160000, 200000, 40000, '2025-05-27 07:03:07'),
(4, 'Bandung', 'VIP', 200000, '2', 'ansrex', 2, 400000, 500000, 100000, '2025-05-27 07:22:21'),
(5, 'Jatibarang', 'Ekonomi', 100000, '45', 'wulan', 4, 400000, 500000, 100000, '2025-05-27 07:44:04'),
(6, 'Tegal', 'VIP', 100000, '23', 'rendry', 3, 300000, 500000, 200000, '2025-05-28 04:31:54'),
(7, 'Jatibarang', 'VIP', 110000, '72', 'andrian', 3, 330000, 1000000, 670000, '2025-05-28 04:44:23'),
(8, 'Bandung', 'Ekonomi', 180000, '2003', 'ANDRIYANI DEWI', 3, 540000, 600000, 60000, '2025-05-28 04:50:25'),
(9, 'Tegal', 'VIP', 110000, '8', 'REZA RAHADIAN', 3, 330000, 1000000, 670000, '2025-05-28 05:08:38'),
(10, 'Bandung', 'Ekonomi', 200000, '32', 'MIHAMAD RIZAL', 10, 2000000, 4000000, 2000000, '2025-05-28 05:10:43'),
(11, 'Tegal', 'VIP', 100000, '9', 'kiyu', 9, 900000, 900000, 0, '2025-05-28 05:18:58'),
(12, 'Yogyakarta', 'VIP', 150000, '45', 'MUHAMAD ADRIAN', 7, 1050000, 2000000, 950000, '2025-05-28 05:31:10'),
(13, 'Yogyakarta', 'Ekonomi', 120000, '3', 'Nayu M', 2, 240000, 300000, 60000, '2025-05-28 05:34:48'),
(14, 'Yogyakarta', 'VIP', 150000, '23', 'rizki', 4, 600000, 1000000, 400000, '2025-05-28 05:39:51'),
(15, 'Bandung', 'VIP', 200000, '2', 'RIZAL', 2, 400000, 500000, 100000, '2025-05-28 06:13:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `fk_jurusan` (`id_jurusan`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `kereta`
--
ALTER TABLE `kereta`
  ADD PRIMARY KEY (`id_kereta`);

--
-- Indexes for table `penumpang`
--
ALTER TABLE `penumpang`
  ADD PRIMARY KEY (`id_penumpang`);

--
-- Indexes for table `transaksi_tiket`
--
ALTER TABLE `transaksi_tiket`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id_jurusan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kereta`
--
ALTER TABLE `kereta`
  MODIFY `id_kereta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `penumpang`
--
ALTER TABLE `penumpang`
  MODIFY `id_penumpang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaksi_tiket`
--
ALTER TABLE `transaksi_tiket`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  ADD CONSTRAINT `fk_jurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
