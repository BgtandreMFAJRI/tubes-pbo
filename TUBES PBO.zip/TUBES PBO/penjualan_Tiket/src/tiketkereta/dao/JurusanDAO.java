/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketkereta.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import tiketkereta.config.Koneksi;

/**
 *
 * @author ASUS
 */
public class JurusanDAO {

    public void isiComboJurusan(JComboBox<String> comboBox) {
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT nama_jurusan FROM jurusan");
            comboBox.removeAllItems();
            while (rs.next()) {
                comboBox.addItem(rs.getString("nama_jurusan"));
            }
        } catch (Exception e) {
            System.out.println("Gagal ambil data jurusan: " + e.getMessage());
        }
    }
}
